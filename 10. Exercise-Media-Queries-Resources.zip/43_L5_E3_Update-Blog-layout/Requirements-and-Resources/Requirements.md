# 03. Update Blog Layout

## Tasks
* Create an **"index.html"** file with title - **"Update Blog Layout"**
* **Copy** the latest code from ***"Blog Layout with Flexbox"***
* **Copy** your multilevel dropdown
* Make the menu **responsive**
* Get the latest **typography.css**
* Move the layout code to **layout.css**
* Move the navigation code to **navigation.css**
* Create **reset.css** file