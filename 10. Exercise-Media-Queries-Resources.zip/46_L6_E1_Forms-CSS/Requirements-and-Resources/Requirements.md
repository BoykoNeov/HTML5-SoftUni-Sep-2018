# 03. Responsive Forms

## Tasks
* Create an **"index.html"** file with title - **"Responsive Forms"**
* Create a simple login form using **semantic html**
* Add **icons** to the input fields using *font awesome*
* Add **focus** state that changes the input and the icon

## Constraints
* Use **semantic HTML** for forms, fieldset, legend etc.
