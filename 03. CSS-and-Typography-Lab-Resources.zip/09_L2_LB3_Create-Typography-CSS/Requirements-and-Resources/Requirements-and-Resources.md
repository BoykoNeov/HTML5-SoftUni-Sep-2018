# 03 - Create Typography CSS

### Constraints
 * Create **"index.html"** and **"style.css"** files
 * Change the **title** in the document
 * Use headings from **h1** to **h6**
 * Create a HTML **table** and style it
 * Use **blockquote** tag
	* Style its left border with **rgb(221,221,221)** color
	* Style its font to **italic**