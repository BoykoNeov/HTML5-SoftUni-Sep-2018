# 02 - Simple Article Page

### Constraints
 * Create **"index.html"** and **"style.css"** files
 * Change the **title** in the document
 * Use background with color - **rgb(238, 238, 238)'**
 * Use **rgb(51, 51, 51)** color for text